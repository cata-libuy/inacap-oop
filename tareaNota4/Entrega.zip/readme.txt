Antes de arrancar, crear base de datos mysql
- nombre base de datos: "javacon1"
- usuario base de datos "javacon1"
- password "123123"
