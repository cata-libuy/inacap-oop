/*
Museo: la clase Museo, lleva el control sobre los museos asociados, 
que solicitan préstamos o reciben préstamos desde este Museo. 
Tienen un identificador, un nombre, una dirección, un contacto y un país.
 */
package Museo;

/**
 *
 * @author cata.orellana
 */
public class java {
    
}
